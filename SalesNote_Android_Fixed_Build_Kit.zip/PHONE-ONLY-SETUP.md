# SalesNote Android APK — phone-only cloud build

This kit contains the original SalesNote Flutter source archive and a GitHub Actions workflow. The workflow builds a **debug APK for testing** in GitHub's cloud; it does not require Android Studio, Flutter, a Mac, or a PC on your side.

## One-time setup from your Samsung phone

1. Download/extract this kit on your phone (or keep the ZIP available in Downloads).
2. In Chrome, sign in to GitHub and create a **private** repository named `salesnote-android-build`.
3. In the repository, use **Add file → Upload files** and upload `salesnote-source.zip` from this kit. Commit it to the `main` branch.
4. Create the workflow file: **Add file → Create new file**. Set its path to `.github/workflows/android-apk.yml` and paste the contents of the `android-apk.yml` file from this kit. Commit it to `main`.
5. Open the repository's **Actions** tab, choose **Build SalesNote Android APK**, and tap **Run workflow** if it has not started automatically.
6. Wait for the run to finish with a green check. Open the completed run, scroll to **Artifacts**, and download `SalesNote-Android-APK`.
7. Extract the downloaded artifact ZIP. Tap `SalesNote-debug.apk` in My Files and approve **Install unknown apps** for the browser/file manager if Android asks. Install and open it.

## Important

- This is a debug-signed APK for your own device testing, not a production-signed client release or Play Store package.
- Keep the GitHub repository private because it contains your source code.
- The app's current Android application ID is `com.makelifeeasy.hanuman_smart_biller_kiosk`; the source project folder is `hanuman-smart-biller-kiosk-main`.
- The build uses the Flutter stable channel and Java 17. If dependency resolution or compilation fails, open the failed Actions run and share its error log; do not change random Gradle or SDK versions.
- The app guide describes local-only data. Uninstalling or clearing app data can lose local shop records; test with sample data first.
- The current Android Gradle release configuration uses the debug signing config. This workflow deliberately builds `--debug` for a first install/test. A proper private release signing key and release workflow should be configured before distributing to clients.
