SalesNote Android cloud build package
=====================================

This package contains:
- salesnote-source.zip: the original Flutter project, unchanged.
- .github/workflows/android-apk.yml: GitHub Actions workflow to build a debug APK.
- PHONE-ONLY-SETUP.md: phone-oriented repository setup instructions.

Build output (after a successful GitHub Actions run):
  SalesNote-debug.apk
  SalesNote-debug.apk.sha256

Important:
- This package is NOT itself an APK.
- The APK is generated only when the GitHub Actions workflow runs successfully.
- The workflow builds a debug-signed APK for testing, not a Play Store release.
- A production release requires a separately configured private signing key. Do not commit signing keys or passwords to the repository.
- The source requires the Flutter/Dart versions declared in pubspec.yaml. The workflow uses the current Flutter stable channel and reports toolchain versions in its logs.
